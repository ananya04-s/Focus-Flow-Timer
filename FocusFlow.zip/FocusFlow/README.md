# ⏱️ FocusFlow Timer

A premium, minimalist productivity timer app built in **Kotlin** for Android, featuring a glassmorphism UI, smooth animations, custom circular progress ring, Stopwatch & Pomodoro modes, Pause/Resume, and a live Statistics card.

---

## 🎯 Project Overview

FocusFlow Timer is a single-screen Android app designed to help users stay focused and productive. It teaches core Android concepts — Handler-based timing, ViewModel for configuration-change survival, LiveData observation, ViewBinding, and custom View drawing — wrapped in a polished, portfolio-ready interface.

---

## ✨ Features

- **Stopwatch Mode** — counts up from `00:00:00`, one ring rotation per hour.
- **Pomodoro Mode** — counts down from `25:00`, ring empties as time elapses.
- **▶ Start / ⏸ Pause / ▶ Resume / ↺ Reset** — full timer lifecycle with no duplicate starts.
- **Custom Circular Progress Ring** — drawn on `Canvas` in `TimerRingView`; sky-blue when idle, emerald-green while running.
- **Glassmorphism Timer Card** — frosted semi-transparent card with a glowing border over the midnight-blue gradient background.
- **Motivational Quotes** — rotate every 10 seconds while the timer is running (`"Keep Going! 🚀"`, `"Stay in the zone! 🔥"`, and more).
- **Statistics Card** — displays current Session time, Best session (persisted across resets), and total Starts for the session.
- **Dark Mode** — full Material 3 dark color scheme via `values-night/colors.xml`.
- **Rotation-safe** — `TimerViewModel` survives screen rotation via AndroidX `ViewModel`.
- **Splash Screen** — branded midnight-blue splash using the AndroidX SplashScreen API.
- **Smooth Animations** — fade-in on launch, button-press scale, pulse ring animation.

---

## 🛠️ Technologies Used

| Layer | Technology |
|---|---|
| Language | Kotlin |
| IDE | Android Studio |
| UI | XML Layouts, Material Design 3, ViewBinding |
| Timer | `Handler.postDelayed` (1 s tick) |
| State | `ViewModel` + `LiveData` |
| Custom UI | `Canvas`-drawn `TimerRingView` |
| Animations | XML `<set>` anims + `View.startAnimation()` |
| Min SDK | 24 · Target/Compile SDK 34 |

---

## 🖼️ Screenshots

> _Add screenshots of the Splash, Idle state, Running state (emerald ring), and Pomodoro mode here._

| Splash | Idle | Running | Pomodoro |
|---|---|---|---|
| _screenshot_ | _screenshot_ | _screenshot_ | _screenshot_ |

---

## 📂 Folder Structure

```
app/src/main/java/com/example/focusflow/
├── FocusFlowApp.kt              # Application class
├── ui/
│   ├── SplashActivity.kt        # 1.5 s branded splash
│   ├── MainActivity.kt          # Timer screen, button logic, LiveData observers
│   └── TimerRingView.kt         # Custom Canvas circular progress ring
├── timer/
│   ├── TimerState.kt            # Enums: TimerState, TimerMode, constants
│   ├── TimerManager.kt          # Handler-based tick engine
│   └── TimerViewModel.kt        # ViewModel wrapping TimerManager + stats
└── util/
    └── FormatUtils.kt           # Seconds → HH:MM:SS formatter

app/src/main/res/
├── layout/
│   ├── activity_splash.xml
│   └── activity_main.xml
├── drawable/                    # gradient BGs, glass cards, button BGs, icon
├── anim/                        # fade_in, pulse, btn_press
├── values/ & values-night/      # colors, strings, themes
└── xml/                         # backup & data extraction rules
```

---

## ⚙️ How the Timer Works

### 1. Handler tick (TimerManager)
```kotlin
private val tickRunnable = object : Runnable {
    override fun run() {
        if (_state.value != TimerState.RUNNING) return
        _elapsedSeconds.value = (_elapsedSeconds.value ?: 0L) + 1L
        handler.postDelayed(this, 1000L)   // schedule next tick in 1 s
    }
}
```

### 2. Prevent duplicate starts
```kotlin
fun start() {
    if (_state.value == TimerState.RUNNING) return  // guard
    _state.value = TimerState.RUNNING
    if (!isScheduled) {
        isScheduled = true
        handler.postDelayed(tickRunnable, 1000L)
    }
}
```

### 3. Reset
```kotlin
fun reset() {
    handler.removeCallbacks(tickRunnable)   // stop immediately
    isScheduled = false
    _state.value = TimerState.IDLE
    _elapsedSeconds.value = 0L             // display returns to 00:00:00
}
```

### 4. Survive rotation
`TimerViewModel` extends `ViewModel` — Android keeps it alive across `Activity` re-creation. The `Handler` inside `TimerManager` runs on the main looper and continues ticking while `MainActivity` re-binds its observers.

---

## 🚀 Setup Instructions

1. **Extract** the zip and open the `FocusFlow` folder in **Android Studio Hedgehog (2023.1.1)** or newer.
2. Let Gradle sync (first run requires internet to download dependencies).
3. Connect a device or start an emulator running **Android 8.0 (API 24)+**.
4. Click **Run ▶**.
5. Tap **▶ Start** to begin counting.
6. Tap **⏸ Pause** to pause without losing progress.
7. Tap **↺ Reset** to stop and return to `00:00:00`.
8. Switch to **🍅 Pomodoro** chip for a 25-minute countdown.

---

## 🔮 Future Enhancements

- Sound notification / vibration when Pomodoro session ends.
- Custom countdown duration input.
- Session history stored in Room database.
- Daily productivity heatmap / streak tracker.
- Lottie animations (confetti on Pomodoro completion).
- Background service so the timer keeps running when the app is minimized.
- Widget for the home screen.

---

## 👤 Author

**FocusFlow Timer** — built as a portfolio/internship project demonstrating Handler-based timing, ViewModel + LiveData, custom Canvas drawing, and Material Design 3 in Kotlin.
