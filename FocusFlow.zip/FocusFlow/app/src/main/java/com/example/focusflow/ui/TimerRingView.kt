package com.example.focusflow.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.example.focusflow.R

/**
 * Custom View that draws a circular progress arc.
 *
 * For stopwatch mode, [progress] grows from 0→1 (one full rotation per hour).
 * For Pomodoro mode, it counts down from 1→0.
 */
class TimerRingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    /** 0.0f (empty) → 1.0f (full ring). Set externally and call invalidate(). */
    var progress: Float = 0f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }

    /** True while timer is running → switches arc color to emerald green. */
    var isRunning: Boolean = false
        set(value) { field = value; invalidate() }

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 14f
        strokeCap = Paint.Cap.ROUND
    }

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 14f
        strokeCap = Paint.Cap.ROUND
    }

    private val oval = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val trackColor = ContextCompat.getColor(context, R.color.progress_track)
        val arcColor = if (isRunning)
            ContextCompat.getColor(context, R.color.progress_arc_running)
        else
            ContextCompat.getColor(context, R.color.progress_arc)

        trackPaint.color = trackColor
        arcPaint.color = arcColor

        val pad = trackPaint.strokeWidth / 2f + paddingLeft
        oval.set(pad, pad, width - pad, height - pad)

        // Full background track
        canvas.drawArc(oval, -90f, 360f, false, trackPaint)

        // Progress arc
        if (progress > 0f) {
            canvas.drawArc(oval, -90f, 360f * progress, false, arcPaint)
        }
    }
}
