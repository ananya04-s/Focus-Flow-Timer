package com.example.focusflow

import android.app.Application

/** Application class — entry point for app-wide init if needed. */
class FocusFlowApp : Application()
