package com.example.focusflow.util

/** Formats a raw second count into HH:MM:SS strings split into parts. */
object FormatUtils {

    data class TimeParts(val hours: String, val minutes: String, val seconds: String)

    fun secondsToParts(totalSeconds: Long): TimeParts {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return TimeParts(
            hours   = "%02d".format(h),
            minutes = "%02d".format(m),
            seconds = "%02d".format(s)
        )
    }

    fun secondsToHHMMSS(totalSeconds: Long): String {
        val p = secondsToParts(totalSeconds)
        return "${p.hours}:${p.minutes}:${p.seconds}"
    }
}
