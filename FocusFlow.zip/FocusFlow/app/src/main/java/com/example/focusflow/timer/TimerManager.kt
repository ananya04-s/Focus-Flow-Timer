package com.example.focusflow.timer

import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

/**
 * TimerManager handles all timer tick logic using [Handler.postDelayed].
 *
 * Design decisions:
 *  - Uses a simple Handler on the main looper (safe for UI updates).
 *  - [elapsedSeconds] for stopwatch; [remainingSeconds] for Pomodoro.
 *  - Exposed as LiveData so MainActivity reacts automatically to changes.
 *  - A guard flag [isScheduled] prevents duplicate Runnable posts.
 */
class TimerManager {

    // ──────────────────────────────────────────────────────────────────
    // LiveData exposed to the UI
    // ──────────────────────────────────────────────────────────────────

    private val _elapsedSeconds = MutableLiveData(0L)
    val elapsedSeconds: LiveData<Long> = _elapsedSeconds

    private val _state = MutableLiveData(TimerState.IDLE)
    val state: LiveData<TimerState> = _state

    private val _mode = MutableLiveData(TimerMode.STOPWATCH)
    val mode: LiveData<TimerMode> = _mode

    // ──────────────────────────────────────────────────────────────────
    // Internal
    // ──────────────────────────────────────────────────────────────────

    private val handler = Handler(Looper.getMainLooper())
    private var isScheduled = false

    /** Pomodoro: starts at POMODORO_SECONDS and counts down */
    private var pomodoroRemaining = POMODORO_SECONDS.toLong()

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (_state.value != TimerState.RUNNING) return

            when (_mode.value) {
                TimerMode.STOPWATCH -> {
                    _elapsedSeconds.value = (_elapsedSeconds.value ?: 0L) + 1L
                }
                TimerMode.POMODORO -> {
                    if (pomodoroRemaining > 0) {
                        pomodoroRemaining--
                        _elapsedSeconds.value = pomodoroRemaining   // reuse field
                    } else {
                        // Pomodoro complete
                        _state.value = TimerState.IDLE
                        isScheduled = false
                        return
                    }
                }
                else -> {}
            }

            handler.postDelayed(this, 1000L)
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Public API
    // ──────────────────────────────────────────────────────────────────

    fun start() {
        if (_state.value == TimerState.RUNNING) return  // prevent duplicate starts

        if (_mode.value == TimerMode.POMODORO && _state.value == TimerState.IDLE) {
            pomodoroRemaining = POMODORO_SECONDS.toLong()
            _elapsedSeconds.value = pomodoroRemaining
        }

        _state.value = TimerState.RUNNING

        if (!isScheduled) {
            isScheduled = true
            handler.postDelayed(tickRunnable, 1000L)
        }
    }

    fun pause() {
        if (_state.value != TimerState.RUNNING) return
        _state.value = TimerState.PAUSED
        // tickRunnable will exit on its next check; no need to remove
    }

    fun resume() {
        if (_state.value != TimerState.PAUSED) return
        _state.value = TimerState.RUNNING
        // Re-schedule tick
        isScheduled = true
        handler.postDelayed(tickRunnable, 1000L)
    }

    fun reset() {
        handler.removeCallbacks(tickRunnable)
        isScheduled = false
        _state.value = TimerState.IDLE
        _elapsedSeconds.value = 0L
        pomodoroRemaining = POMODORO_SECONDS.toLong()
    }

    fun setMode(newMode: TimerMode) {
        if (_state.value != TimerState.IDLE) return  // don't switch mid-session
        _mode.value = newMode
        _elapsedSeconds.value = if (newMode == TimerMode.POMODORO) POMODORO_SECONDS.toLong() else 0L
    }

    /** Call from Activity.onDestroy to avoid leaking the Handler. */
    fun destroy() {
        handler.removeCallbacksAndMessages(null)
    }
}
