package com.example.focusflow.timer

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * Wraps [TimerManager] inside a [ViewModel] so timer state survives
 * screen rotation and other configuration changes.
 */
class TimerViewModel : ViewModel() {

    val manager = TimerManager()

    // ── Stats ─────────────────────────────────────────────────────────
    private val _totalStarts = MutableLiveData(0)
    val totalStarts: LiveData<Int> = _totalStarts

    private val _bestSeconds = MutableLiveData(0L)
    val bestSeconds: LiveData<Long> = _bestSeconds

    // Convenience delegates
    val elapsedSeconds: LiveData<Long> = manager.elapsedSeconds
    val timerState: LiveData<TimerState> = manager.state
    val timerMode: LiveData<TimerMode> = manager.mode

    fun start() {
        manager.start()
        _totalStarts.value = (_totalStarts.value ?: 0) + 1
    }

    fun pause() = manager.pause()

    fun resume() = manager.resume()

    fun reset() {
        // Update best session before resetting
        val elapsed = manager.elapsedSeconds.value ?: 0L
        if (manager.mode.value == TimerMode.STOPWATCH && elapsed > (_bestSeconds.value ?: 0L)) {
            _bestSeconds.value = elapsed
        }
        manager.reset()
    }

    fun setMode(mode: TimerMode) = manager.setMode(mode)

    override fun onCleared() {
        super.onCleared()
        manager.destroy()
    }
}
