package com.example.focusflow.ui

import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.focusflow.R
import com.example.focusflow.databinding.ActivityMainBinding
import com.example.focusflow.timer.POMODORO_SECONDS
import com.example.focusflow.timer.TimerMode
import com.example.focusflow.timer.TimerState
import com.example.focusflow.timer.TimerViewModel
import com.example.focusflow.util.FormatUtils

/**
 * MainActivity — the single-screen timer UI.
 *
 * Responsibilities:
 *  ▸ Observe [TimerViewModel] LiveData and update Views.
 *  ▸ Handle Start / Pause / Resume / Reset button clicks.
 *  ▸ Drive the custom [TimerRingView] progress ring.
 *  ▸ Rotate motivational messages every N seconds.
 *  ▸ Switch between Stopwatch and Pomodoro modes via chips.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val vm: TimerViewModel by viewModels()

    // Motivational messages cycled every 10 seconds
    private val quotes = listOf(
        "Keep Going! 🚀",
        "Stay Focused 💡",
        "Every Second Counts ⏳",
        "Focus creates success.",
        "Small progress is still progress.",
        "Consistency beats intensity.",
        "Stay in the zone! 🔥",
        "You've got this! 💪"
    )
    private var quoteIndex = 0

    // ──────────────────────────────────────────────────────────────────
    // Lifecycle
    // ──────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fadeInContent()
        observeViewModel()
        setupButtons()
        setupModeChips()
    }

    // ──────────────────────────────────────────────────────────────────
    // Animations
    // ──────────────────────────────────────────────────────────────────

    private fun fadeInContent() {
        val fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        binding.rootLayout.startAnimation(fadeIn)
    }

    // ──────────────────────────────────────────────────────────────────
    // ViewModel observation
    // ──────────────────────────────────────────────────────────────────

    private fun observeViewModel() {
        vm.elapsedSeconds.observe(this) { seconds ->
            updateTimerDisplay(seconds)
            updateRingProgress(seconds)
            updateStatSession(seconds)
        }

        vm.timerState.observe(this) { state ->
            updateButtonVisibility(state)
            updateStatusMessage(state)
            updateRingRunningState(state)
        }

        vm.totalStarts.observe(this) { starts ->
            binding.tvStatStarts.text = starts.toString()
        }

        vm.bestSeconds.observe(this) { best ->
            binding.tvStatBest.text = FormatUtils.secondsToHHMMSS(best)
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Button setup
    // ──────────────────────────────────────────────────────────────────

    private fun setupButtons() {
        val pressAnim = AnimationUtils.loadAnimation(this, R.anim.btn_press)

        binding.btnStart.setOnClickListener {
            it.startAnimation(pressAnim)
            vm.start()
        }

        binding.btnPause.setOnClickListener {
            it.startAnimation(pressAnim)
            val state = vm.timerState.value
            if (state == TimerState.RUNNING) {
                vm.pause()
            } else if (state == TimerState.PAUSED) {
                vm.resume()
            }
        }

        binding.btnReset.setOnClickListener {
            it.startAnimation(pressAnim)
            stopQuoteRotation()
            vm.reset()
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Mode chips
    // ──────────────────────────────────────────────────────────────────

    private fun setupModeChips() {
        binding.chipStopwatch.setOnClickListener {
            if (vm.timerMode.value == TimerMode.STOPWATCH) return@setOnClickListener
            vm.setMode(TimerMode.STOPWATCH)
            binding.chipStopwatch.background = getDrawable(R.drawable.bg_chip_active)
            binding.chipStopwatch.setTextColor(0xFFFFFFFF.toInt())
            binding.chipPomodoro.background = getDrawable(R.drawable.bg_chip_inactive)
            binding.chipPomodoro.setTextColor(0xAAAACCEA.toInt())
        }

        binding.chipPomodoro.setOnClickListener {
            if (vm.timerMode.value == TimerMode.POMODORO) return@setOnClickListener
            vm.setMode(TimerMode.POMODORO)
            binding.chipPomodoro.background = getDrawable(R.drawable.bg_chip_active)
            binding.chipPomodoro.setTextColor(0xFFFFFFFF.toInt())
            binding.chipStopwatch.background = getDrawable(R.drawable.bg_chip_inactive)
            binding.chipStopwatch.setTextColor(0xAAAACCEA.toInt())
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // UI updates
    // ──────────────────────────────────────────────────────────────────

    private fun updateTimerDisplay(seconds: Long) {
        val parts = FormatUtils.secondsToParts(seconds)
        binding.tvHours.text   = parts.hours
        binding.tvMinutes.text = parts.minutes
        binding.tvSeconds.text = parts.seconds
    }

    private fun updateRingProgress(seconds: Long) {
        val progress = when (vm.timerMode.value) {
            TimerMode.POMODORO -> {
                // Counts down: full ring at start, empty at end
                seconds.toFloat() / POMODORO_SECONDS.toFloat()
            }
            else -> {
                // Counts up: one full rotation every 3600 s (1 hour)
                (seconds % 3600).toFloat() / 3600f
            }
        }
        binding.timerRing.progress = progress
    }

    private fun updateRingRunningState(state: TimerState) {
        binding.timerRing.isRunning = (state == TimerState.RUNNING)
    }

    private fun updateButtonVisibility(state: TimerState) {
        when (state) {
            TimerState.IDLE -> {
                binding.btnStart.visibility  = View.VISIBLE
                binding.btnStart.isEnabled   = true
                binding.btnPause.visibility  = View.GONE
            }
            TimerState.RUNNING -> {
                binding.btnStart.visibility  = View.GONE
                binding.btnPause.visibility  = View.VISIBLE
                binding.btnPause.text        = getString(R.string.btn_pause)
                startQuoteRotation()
            }
            TimerState.PAUSED -> {
                binding.btnStart.visibility  = View.GONE
                binding.btnPause.visibility  = View.VISIBLE
                binding.btnPause.text        = getString(R.string.btn_resume)
            }
        }
    }

    private fun updateStatusMessage(state: TimerState) {
        when (state) {
            TimerState.IDLE    -> binding.tvStatus.text = getString(R.string.status_ready)
            TimerState.RUNNING -> binding.tvStatus.text = quotes[quoteIndex % quotes.size]
            TimerState.PAUSED  -> binding.tvStatus.text = getString(R.string.status_paused)
        }
    }

    private fun updateStatSession(seconds: Long) {
        binding.tvStatSession.text = FormatUtils.secondsToHHMMSS(seconds)
    }

    // ──────────────────────────────────────────────────────────────────
    // Quote rotation (every 10 s while running)
    // ──────────────────────────────────────────────────────────────────

    private val quoteRunnable = object : Runnable {
        override fun run() {
            if (vm.timerState.value != TimerState.RUNNING) return
            quoteIndex++
            binding.tvStatus.text = quotes[quoteIndex % quotes.size]
            binding.tvStatus.postDelayed(this, 10_000L)
        }
    }

    private fun startQuoteRotation() {
        binding.tvStatus.removeCallbacks(quoteRunnable)
        binding.tvStatus.postDelayed(quoteRunnable, 10_000L)
    }

    private fun stopQuoteRotation() {
        binding.tvStatus.removeCallbacks(quoteRunnable)
    }
}
