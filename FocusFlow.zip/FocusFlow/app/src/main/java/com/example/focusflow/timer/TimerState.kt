package com.example.focusflow.timer

/** Represents the three possible states of the FocusFlow timer. */
enum class TimerState { IDLE, RUNNING, PAUSED }

/** Timer mode: count-up stopwatch or fixed-duration Pomodoro countdown. */
enum class TimerMode {
    STOPWATCH,            // counts up from 00:00:00
    POMODORO              // counts down from 25:00
}

const val POMODORO_SECONDS = 25 * 60  // 25 minutes
